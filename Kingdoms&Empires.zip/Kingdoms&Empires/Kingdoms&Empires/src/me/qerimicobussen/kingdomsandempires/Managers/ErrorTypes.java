package me.qerimicobussen.kingdomsandempires.Managers;

public enum ErrorTypes {
	PLAYER_ONLY_COMMAND,
	DOES_NOT_HAVE_PERMISSION,
	WRONG_ARGS,
	NATION_ALREADY_EXIST
	
}
