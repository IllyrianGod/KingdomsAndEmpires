package me.qerimicobussen.kingdomsandempires.Menus;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import me.qerimicobussen.kingdomsandempires.Managers.ChatColorManager;
import me.qerimicobussen.kingdomsandempires.Managers.MenuManager;

public class JobsMenu implements Listener {
	
	public HashMap<String, String> jobs = new HashMap<String, String>();

	public Inventory inv;
	private ItemStack a1, b1, c1, d1, e1, f1, g1;
	private ItemStack a2, b2, c2, d2, e2;
	public JobsMenu menu;

	public JobsMenu() {
		inv = Bukkit.getServer().createInventory(null, 18,
				ChatColorManager.CCM("                   &3&l~~{&6&lJobMenu&3&l}~~"));

		// Inv Line 1
		a1 = MenuManager.createItem(Material.IRON_HOE, "Farmer");
		b1 = MenuManager.createItem(Material.IRON_PICKAXE, "Miner");
		c1 = MenuManager.createItem(Material.WOOD_SWORD, "Hunter");
		d1 = MenuManager.createItem(Material.BRICK, "Builder");
		e1 = MenuManager.createItem(Material.STONE_AXE, "Lumberjack");
		f1 = MenuManager.createItem(Material.FISHING_ROD, "Fisher");
		g1 = MenuManager.createItem(Material.CHEST, "Merchant");

		inv.setItem(1, a1);
		inv.setItem(2, b1);
		inv.setItem(3, c1);
		inv.setItem(4, d1);
		inv.setItem(5, e1);
		inv.setItem(6, f1);
		inv.setItem(7, g1);

		// Inv Line 2
		a2 = MenuManager.createItem(Material.STONE_SWORD, "Swordman");
		b2 = MenuManager.createItem(Material.BOW, "Archer");
		c2 = MenuManager.createItem(Material.IRON_SWORD, "Knight");
		d2 = MenuManager.createItem(Material.SHIELD, "Guard");
		e2 = MenuManager.createItem(Material.IRON_AXE, "Axeman");

		inv.setItem(10, a2);
		inv.setItem(11, b2);
		inv.setItem(12, c2);
		inv.setItem(13, d2);
		inv.setItem(14, e2);
	}

	public void ShowJobs(Player p) {
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onInvClickJM(InventoryClickEvent e) {
		if (!e.getInventory().equals(inv))
			return;

		// Inv Line 1
		if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Farmer")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &2&lFarmer&r"));
			jobs.put(e.getWhoClicked().getName(), "Farmer");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Miner")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &7&lMiner&r"));
			jobs.put(e.getWhoClicked().getName(), "Miner");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Hunter")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &4&lHunter&r"));
			jobs.put(e.getWhoClicked().getName(), "Hunter");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Builder")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &e&lBuilder&r"));
			jobs.put(e.getWhoClicked().getName(), "Builder");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Lumberjack")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &a&lLumberjack&r"));
			jobs.put(e.getWhoClicked().getName(), "Lumberjack");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Fisher")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &9&lFisher&r"));
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Merchant")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &5&lMerchant&r"));
			jobs.put(e.getWhoClicked().getName(), "Merchant");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();

			// Inv Line 2
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Swordman")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &8&lSwordman&r"));
			jobs.put(e.getWhoClicked().getName(), "Swordsman");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Archer")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &8&lArcher&r"));
			jobs.put(e.getWhoClicked().getName(), "Archer");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Knight")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &8&lKnight&r"));
			jobs.put(e.getWhoClicked().getName(), "Knight");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Guard")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &8&lGuard&r"));
			jobs.put(e.getWhoClicked().getName(), "Guard");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		} else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Axeman")) {
			e.getWhoClicked().sendMessage(ChatColorManager.CCM("&6&lYour Job Is Now: &8&lAxeman&r"));
			jobs.put(e.getWhoClicked().getName(), "Axeman");
			e.setCancelled(true);
			e.getWhoClicked().closeInventory();
		}
	}
}